/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};

/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {

/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId])
/******/ 			return installedModules[moduleId].exports;

/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			exports: {},
/******/ 			id: moduleId,
/******/ 			loaded: false
/******/ 		};

/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);

/******/ 		// Flag the module as loaded
/******/ 		module.loaded = true;

/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}


/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;

/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;

/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";

/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(0);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ function(module, exports, __webpack_require__) {

	"use strict";
	var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
	    return new (P || (P = Promise))(function (resolve, reject) {
	        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
	        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
	        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
	        step((generator = generator.apply(thisArg, _arguments || [])).next());
	    });
	};
	Object.defineProperty(exports, "__esModule", { value: true });
	const config_1 = __webpack_require__(1);
	const jira_data_1 = __webpack_require__(3);
	const dom = __webpack_require__(4);
	config_1.getConfig().then(config => {
	    if (!window.GITHUB_JIRA_SCRIPT_INJECTED) {
	        window.GITHUB_JIRA_SCRIPT_INJECTED = true;
	        console.log('Injecting Content Script');
	        const CLASS_ROW_DISCOVERED = 'gh-jira-script-discovered';
	        const getMatchingJira = (issueURL) => {
	            const pathSplit = issueURL.pathname.split('/');
	            if (pathSplit.length < 3)
	                return null;
	            const owner = pathSplit[1];
	            const repo = pathSplit[2];
	            for (const c of config) {
	                if (c.gitHubDomain === window.location.hostname) {
	                    if ((c.repos.scope === 'all') ||
	                        (c.repos.scope === 'owner' && c.repos.owner === owner) ||
	                        (c.repos.scope === 'single' && c.repos.owner === owner && c.repos.repo === repo)) {
	                        return c.jiraBaseUrl;
	                    }
	                }
	            }
	            return null;
	        };
	        const updateIssueRow = (row) => __awaiter(this, void 0, void 0, function* () {
	            const issueLink = row.querySelector('a[data-hovercard-type="issue"]') ||
	                row.querySelector('a[data-hovercard-type="pull_request"]') ||
	                row.querySelector('a.h4.link-gray-dark');
	            if (!issueLink)
	                return;
	            const href = issueLink.href;
	            if (!href)
	                return;
	            const issueURL = new URL(href);
	            const jira = getMatchingJira(issueURL);
	            if (jira) {
	                let labels = row.querySelector('.labels');
	                if (!labels) {
	                    labels = document.createElement('span');
	                    labels.className = 'labels lh-default';
	                    const parent = issueLink.parentNode;
	                    if (!(parent instanceof Element))
	                        return;
	                    parent.insertBefore(labels, parent.querySelector('.text-small'));
	                }
	                const loading = dom.createLoadingLabel();
	                labels.appendChild(loading);
	                const info = yield jira_data_1.loadJiraData(issueURL, jira);
	                loading.remove();
	                for (const i of info) {
	                    const label = dom.createJiraLabel(i);
	                    labels.appendChild(document.createTextNode(' '));
	                    labels.appendChild(label);
	                }
	            }
	        });
	        const updateIssues = () => {
	            for (const elem of document.querySelectorAll('.js-issue-row')) {
	                if (elem.classList.contains(CLASS_ROW_DISCOVERED))
	                    continue;
	                elem.classList.add(CLASS_ROW_DISCOVERED);
	                updateIssueRow(elem);
	            }
	        };
	        const observer = new MutationObserver(mutations => {
	            updateIssues();
	        });
	        observer.observe(document, { attributes: true, childList: true, subtree: true });
	        updateIssues();
	    }
	});


/***/ },
/* 1 */
/***/ function(module, exports) {

	"use strict";
	Object.defineProperty(exports, "__esModule", { value: true });
	const STORAGE_KEY = 'links';
	function getConfig() {
	    return new Promise(resolve => {
	        chrome.storage.sync.get(data => {
	            if (data[STORAGE_KEY]) {
	                resolve(data[STORAGE_KEY]);
	            }
	            else {
	                resolve([]);
	            }
	        });
	    });
	}
	exports.getConfig = getConfig;
	function setConfig(config) {
	    return new Promise(resolve => {
	        chrome.storage.sync.set({ [STORAGE_KEY]: config }, resolve);
	    });
	}
	exports.setConfig = setConfig;
	function addListener(l) {
	    chrome.storage.onChanged.addListener((changes, namespace) => {
	        if (changes[STORAGE_KEY]) {
	            l(changes[STORAGE_KEY].newValue);
	        }
	    });
	}
	exports.addListener = addListener;


/***/ },
/* 2 */,
/* 3 */
/***/ function(module, exports) {

	"use strict";
	var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
	    return new (P || (P = Promise))(function (resolve, reject) {
	        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
	        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
	        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
	        step((generator = generator.apply(thisArg, _arguments || [])).next());
	    });
	};
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.StatusColors = {
	    'medium-gray': { bg: '#ccc', text: '#333' },
	    'green': { bg: '#14892c', text: '#fff' },
	    'yellow': { bg: '#ffd351', text: '#594300' },
	    'brown': { bg: '#815b3a', text: '#fff' },
	    'warm-red': { bg: '#d04437', text: '#fff' },
	    'blue-gray': { bg: '#4a6785', text: '#fff' },
	};
	const cache = new Map();
	function loadJiraData(issueUrl, jiraUrl) {
	    return __awaiter(this, void 0, void 0, function* () {
	        let jiraMap = cache.get(jiraUrl);
	        if (!jiraMap) {
	            jiraMap = new Map();
	            cache.set(jiraUrl, jiraMap);
	        }
	        const issueLinks = jiraMap.get(issueUrl.href);
	        if (issueLinks)
	            return issueLinks;
	        console.log('loadJiraData', issueUrl, jiraUrl);
	        const url = `${jiraUrl}/rest/api/2/search?jql=text%20~%20"${encodeURIComponent(issueUrl.href)}"`;
	        console.log(url);
	        const response = yield fetch(url);
	        const body = yield response.text();
	        const json = JSON.parse(body);
	        const result = [];
	        for (const issue of json.issues) {
	            result.push({
	                name: issue.key,
	                url: `${jiraUrl}/browse/${issue.key}`,
	                status: issue.fields.status.name,
	                statusColor: issue.fields.status.statusCategory.colorName
	            });
	        }
	        jiraMap.set(issueUrl.href, result);
	        return result;
	    });
	}
	exports.loadJiraData = loadJiraData;


/***/ },
/* 4 */
/***/ function(module, exports, __webpack_require__) {

	"use strict";
	Object.defineProperty(exports, "__esModule", { value: true });
	const jira_data_1 = __webpack_require__(3);
	function createLoadingLabel() {
	    const a = document.createElement('a');
	    a.innerText = 'Loading Jira...';
	    a.className = 'IssueLabel d-inline-block v-align-text-top';
	    a.style.backgroundColor = '#333';
	    a.style.color = '#fff';
	    return a;
	}
	exports.createLoadingLabel = createLoadingLabel;
	function createJiraLabel(jira) {
	    const a = document.createElement('a');
	    a.innerText = jira.name;
	    a.className = 'IssueLabel d-inline-block v-align-text-top';
	    a.style.backgroundColor = '#333';
	    a.style.color = '#fff';
	    a.href = jira.url;
	    a.target = '_blank';
	    a.rel = 'nofollow noopener';
	    const status = document.createElement('span');
	    a.appendChild(status);
	    status.innerText = jira.status;
	    status.style.marginLeft = '5px';
	    status.style.background = jira_data_1.StatusColors[jira.statusColor].bg;
	    status.style.color = jira_data_1.StatusColors[jira.statusColor].text;
	    status.style.padding = '1px 4px';
	    status.style.borderRadius = '3px';
	    status.style.fontSize = '11px';
	    status.style.border = '1px solid rgba(255, 255, 255, 0.4)';
	    return a;
	}
	exports.createJiraLabel = createJiraLabel;


/***/ }
/******/ ]);