/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};

/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {

/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId])
/******/ 			return installedModules[moduleId].exports;

/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			exports: {},
/******/ 			id: moduleId,
/******/ 			loaded: false
/******/ 		};

/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);

/******/ 		// Flag the module as loaded
/******/ 		module.loaded = true;

/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}


/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;

/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;

/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";

/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(0);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ function(module, exports, __webpack_require__) {

	"use strict";
	Object.defineProperty(exports, "__esModule", { value: true });
	const config_1 = __webpack_require__(1);
	const permissions_1 = __webpack_require__(2);
	const grantedOrigins = new Set();
	function checkPermissions() {
	    console.log('checking permissions');
	    chrome.permissions.getAll(permissions => {
	        grantedOrigins.clear();
	        if (permissions.origins) {
	            for (const origin of permissions.origins)
	                grantedOrigins.add(origin);
	        }
	        console.log('permissions: ', permissions, grantedOrigins);
	    });
	}
	checkPermissions();
	chrome.permissions.onAdded.addListener(checkPermissions);
	chrome.permissions.onRemoved.addListener(checkPermissions);
	let config = [];
	config_1.addListener(c => config = c);
	config_1.getConfig().then(c => config = c);
	chrome.browserAction.onClicked.addListener(tab => {
	    chrome.runtime.openOptionsPage();
	    const missingOrigins = permissions_1.missingOriginPermissions(config, grantedOrigins);
	    console.log('Missing Origins:', missingOrigins);
	    if (missingOrigins.length > 0) {
	        chrome.permissions.request({ origins: missingOrigins });
	    }
	});
	chrome.runtime.onInstalled.addListener(function (object) {
	    chrome.runtime.openOptionsPage();
	});
	chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
	    if (changeInfo.status === 'complete') {
	        intectContentScripts(tab);
	    }
	});
	chrome.tabs.query({}, tabs => {
	    tabs.map(intectContentScripts);
	});
	function intectContentScripts(tab) {
	    if (!tab.url || !tab.id)
	        return;
	    const url = new URL(tab.url);
	    for (const c of config) {
	        if (url.host === c.gitHubDomain) {
	            chrome.tabs.executeScript(tab.id, {
	                file: 'content-scripts/github.js'
	            });
	        }
	    }
	}


/***/ },
/* 1 */
/***/ function(module, exports) {

	"use strict";
	Object.defineProperty(exports, "__esModule", { value: true });
	const STORAGE_KEY = 'links';
	function getConfig() {
	    return new Promise(resolve => {
	        chrome.storage.sync.get(data => {
	            if (data[STORAGE_KEY]) {
	                resolve(data[STORAGE_KEY]);
	            }
	            else {
	                resolve([]);
	            }
	        });
	    });
	}
	exports.getConfig = getConfig;
	function setConfig(config) {
	    return new Promise(resolve => {
	        chrome.storage.sync.set({ [STORAGE_KEY]: config }, resolve);
	    });
	}
	exports.setConfig = setConfig;
	function addListener(l) {
	    chrome.storage.onChanged.addListener((changes, namespace) => {
	        if (changes[STORAGE_KEY]) {
	            l(changes[STORAGE_KEY].newValue);
	        }
	    });
	}
	exports.addListener = addListener;


/***/ },
/* 2 */
/***/ function(module, exports) {

	"use strict";
	Object.defineProperty(exports, "__esModule", { value: true });
	function missingOriginPermissions(config, grantedOrigins) {
	    const missing = new Set();
	    for (const conf of config) {
	        const gh = `https://${conf.gitHubDomain}/*`;
	        const jira = `${conf.jiraBaseUrl}/*`;
	        if (!grantedOrigins.has(gh))
	            missing.add(gh);
	        if (!grantedOrigins.has(jira))
	            missing.add(jira);
	    }
	    return Array.from(missing);
	}
	exports.missingOriginPermissions = missingOriginPermissions;
	function unneededOriginPermissions(config, grantedOrigins) {
	    const needed = new Set();
	    for (const conf of config) {
	        needed.add(`https://${conf.gitHubDomain}/*`);
	        needed.add(`${conf.jiraBaseUrl}/*`);
	    }
	    const unneeded = new Set();
	    for (const origin of grantedOrigins) {
	        if (!needed.has(origin))
	            unneeded.add(origin);
	    }
	    return Array.from(unneeded);
	}
	exports.unneededOriginPermissions = unneededOriginPermissions;


/***/ }
/******/ ]);